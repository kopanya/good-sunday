
$('.start').click(function(event) {
    var $this = $(this);

    $.ajax({
        url: '/s',
        dataType: 'json',
        data: {id: $this.attr('data-id'), port: $('#'+$this.attr('data-id')).val()}
    })
    .done(function(res) {
        console.log("success");
        if(res.is) window.location.reload();
        else console.log('操作失败，请查看后台日志');
    })
    .fail(function() {
        console.log("error");
    })
    .always(function() {
        console.log("complete");
    });

    return;
});

$('.kill').click(function(event) {

    var $this = $(this);

    $.ajax({
        url: '/e',
        dataType: 'json',
        data: {id: $this.attr('data-id')}
    })
    .done(function(res) {
        console.log("success");
        if(res.is) window.location.reload();
        else console.log('操作失败，请查看后台日志');
    })
    .fail(function() {
        console.log("error");
    })
    .always(function() {
        console.log("complete");
    });
    return;
});
