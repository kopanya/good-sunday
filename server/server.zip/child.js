/**
 * Module dependencies.
 */
var child = require('child_process');

var _E = function(port, cb) {

  // 查到被占用的端口号
  child.exec('netstat -aon|findstr ' + port,
    function (error, stdout, stderr) {
     // console.log('stdout: ' + stdout);
      var starr = stdout.split('\n');
   //   console.log('starr[0]: ' + starr[0]);
      var starrr = starr[0].split(/\s+/);
      starrr = starrr.filter(function(val) {
        return !!val;
      });
      var currport = starrr[1].replace(/^.+:(.*)$/g, '$1');

      if(port == currport) {
        console.log('有已占用的端口：', currport);
        // 查找进程PID使用的程序
        child.exec('tasklist|findstr '+starrr[4],
          function (error, stdout, stderr) {
            var starr = stdout.split('\n');
       //     console.log('starr[0]: ' + starr[0]);
            if (error !== null) {
              console.log('exec error: ' + error);
            }
        });
        // KISS PID
        child.exec('taskkill /F /PID '+starrr[4],
          function (error, stdout, stderr) {
            cb(1);
            if (error !== null) {
              console.log('exec error: ' + error);
            }
        });

      }else {
        console.log('无已占用的端口~~~');
        cb(1);
      }
      console.log('starrr: ' + starrr);
    //  console.log(stdout);
      if (error !== null) {
        console.log('exec error: ' + error);
      }
  });

}


process.on('message', function(m) {
  console.log('需要查询和KILL的端口为：', m);
  _E(m, function(is) {
    console.log('返回child的信息', is);
    process.send(is);
    process.kill(process.pid);
  });
});

