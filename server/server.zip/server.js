
var path = require('path');
var fs = require('fs');
var async = require('async');
var child = require('child_process');
/**-----------------文件处理S---------------**/
var _p = path.join(__dirname, '..');

// 获取文件列表
var _fs = fs.readdirSync(_p);
//console.log(_p);

var _xfs = {}, p, mf;
_fs.forEach(function (f) {
    //console.log(f);
    p = path.join(_p, f, '/.server');
 //   console.log(p);
    try{
        mf = fs.readFileSync(p);
    }catch(e) {
        //console.log(e);
        mf = '';
    }
    if(mf) {
        _xfs[f] = {file:f ,server: path.join(_p, f, '/server.js'),port: JSON.parse(mf.toString()).port};
    //    console.log(_xfs);
    }

});
/**-----------------文件处理E---------------**/

var Start = function(query, cb) {
    console.log(query);
    var xfs = _xfs[query.id];
    xfs.port = query.port;
    async.waterfall([
        function(next) {
            var _s = child.fork('child.js');
            _s.on('message', function(is) {
                console.log('接受返回的信息：',is);
                var err;
                next(err, is);
            });
            _s.send(query.port);
        },
        function(results, next) {
            var _s = child.fork(xfs.server, ['port='+query.port]);

            _s.on('message', function(pid) {
                console.log('接受返回的信息PID：', pid);

                var err;
                next(err, pid);
            });
        //    _s.send(query.port);

            _s.on('exit', function() {
              console.log('退出前执行');
            });

            _s.on('close', function() {
              console.log('退出前执行');
            });
        },
        function(pid, next) {

            for(var i in _xfs) {
                var item = _xfs[i];
                if(i == query.id) {
                    xfs.pid = pid;
                    xfs.status = true;
                //    xfs.se =
                }else if(item.port == xfs.port) {
                    item.pid = 0;
                    item.status = false;
                }
            }
            var err;
            next(err, 1);
        }], cb);

}

var End = function(query, cb) {
    console.log(query);
    var xfs = _xfs[query.id];
    async.waterfall([
        function(next) {
            try{
                process.kill(xfs.pid);
            }catch(e) {}
            var err;
            next(err, 1);
        },
        function(pid, next) {
            xfs.pid = 0;
            xfs.status = false;
            var err;
            next(err, 1);
        }], cb);

}

/**-----------------WEB服务S---------------**/
var express = require('express');
var http = require('http');
var app = express();
var jade = require('jade');
app.set('port', '1234');

app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');
app.use(express.static('public'));
app.all('/', function(req, res) {
    res.render('index', {items: _xfs});
});
app.all('/s', function(req, res) {

    Start(req.query, function(err, result) {
        if(err) res.send({is:0});
        else  res.send({is:1});
    });
});
app.all('/e', function(req, res) {
    End(req.query, function(err, result) {
        if(err) res.send({is:0});
        else  res.send({is:1});
    });
});

app.all('/list', function(req, res) {

    res.send(_xfs);
});

var server = http.createServer(app);
var url = "http://127.0.0.1:1234/";
function start() {
  server.listen(app.get('port'), function(){
    setTimeout(function() {
      require('open')(url);
    },500);
    console.log('Express server listening on port ' + app.get('port'));
  });
}
start();
/**-----------------WEB服务E---------------**/
