package send_text_msg;
use lib '/root/scanwx/lib';
use sync;
sub send_text_msg{


# $self->{FromUserName}=$FromUserName;
# $self->{UserName}=$ToUserName;
# $self->{recm}=$recm;


my $self=shift;
my $recm=$self->{recm};
my $FromUserName=$self->{FromUserName};
my $UserName=$self->{UserName};

if ($recm =~ /test/){
sync::sync($self,"{test from scan!}",$UserName,$FromUserName);
}else{
return;
};
};
1;
