package init;
use LWP::UserAgent;
use URI::Escape;
use Net::Ping;
use JSON qw(encode_json);
use Socket;
use Net::SMTP;
use LWP;
use LWP::Simple;
use LWP::UserAgent;
use HTTP::Cookies;
use HTTP::Headers;
use HTTP::Response;
use Encode;
use URI::Escape;
use URI::URL;
use File::Temp qw/tempfile/;
use AE;

sub init {
my $self=shift;
#my $response= $browser->post("https://wx.qq.com/cgi-bin/mmwebwx-bin/webwxinit", [ "r" => "-$now","lang" => "zh_CN","pass_ticket"=>"$pass_ticket"]);
my $now=$self->{now};
my $pass_ticket=$self->{pass_ticket};
my     $login_url =
"https://wx.qq.com/cgi-bin/mmwebwx-bin/webwxinit?r=-$now&lang=zh_CN&pass_ticket=$pass_ticket";
    my $post = {
        BaseRequest => {
            Uin      => $self->{wxuin},
            Sid      => $self->{wxsid},
            Skey     => $self->{Skey},
            DeviceID => $self->{DeviceID},
        }
    };
    use JSON qw(encode_json);
    $json_string = encode_json($post);

    my $req = HTTP::Request->new(
        'POST' => $login_url,
        [ 'r' => "-$now", 'lang' => 'zh_CN', 'pass_ticket' => "$pass_ticket" ]
    );
    $req->referer("https://wx.qq.com/?&lang=zh_CN");
    $req->content_type('application/json; charset=UTF-8')
      ;    #post����,����з��Ͳ���������Ҫ�����
    $req->content("$json_string");    #����post�Ĳ���
    my $res = $self->{ua}->request($req);

#print "-------------init-----------------\n";
#print $res->status_line."\n";
#print $res->as_string();#��ȡ����ԭʼ���ݣ�������Ӧͷ����Ӧ����
    print $res->content();            #��ȡ������Ӧ����
    $d = $res->content();

##���� encode_json decode_json
    use JSON qw/encode_json decode_json/;
    $d = encode_utf8($d);
    $d = decode_json($d);


    foreach $m ( @{ $d->{ContactList} } ) {

        #print "----------------\n";
        #print $m->{UserName};
        if ( $m->{UserName} =~ /\@\@/ ) {
            push( @chatroom_id, $m->{UserName} );
        }
        print "\n";

    };


    $m  = $d->{SyncKey};
    @n = $m->{List};
 
    $count = $m->{Count};

    #print "\$count is $count\n";
    for ( $i = 0 ; $i <= $count - 1 ; $i++ ) {

        #print $m->{List}->[$i]->{Val};
        #print $m->{List}->[$i]->{Key};
        $synckey .= "$m->{List}->[$i]->{Key}\_$m->{List}->[$i]->{Val}\|";


    };


    $synckey =~ s/\|$//;
    $synckey = uri_escape($synckey);
    print "\$synckey is $synckey\n";
	 $self->{synckey}=$synckey ;
	 $self->{m}=$m;
	 };
	 1;