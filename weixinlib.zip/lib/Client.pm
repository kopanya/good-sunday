package Client;
use strict;
use File::Spec;
use Weixin::Util;
use LWP::UserAgent;
use Weixin::UserAgent;
use LWP::Protocol::https;
no strict;
no warnings;
use base qw(qrcode blogin login eventloop init synccheck sync send_text_msg );
my $agent = 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062'; 
my $tmpdir = File::Spec->tmpdir();
my $cookie_filename = $p{login_file} || "$tmpdir/weixin_client_login.dat";

sub new{
    my $class = shift;
    my   %p = @_;
	  my $self={
		    Version =>"1.0",
                        now   => time(),
                        interval =>5,
			cookie_jar    => HTTP::Cookies->new(hide_cookie2=>1,file=>$cookie_filename,autosave=>1)
	  };
		
		 $self->{ua} = LWP::UserAgent->new(
        cookie_jar      =>  $self->{cookie_jar},
        agent           =>  $agent,
        timeout         =>  300,
        ssl_opts        =>  {verify_hostname => 0});

			
	 bless $self,$class;
    return $self;
};
	1;

