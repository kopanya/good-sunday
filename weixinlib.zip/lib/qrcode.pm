package qrcode;
use File::Temp qw/tempfile/;
sub get_qrcode {
my $self =shift;
my $now  = $self->{'now'};

my $url="https://login.weixin.qq.com/jslogin?appid=wx782c26e4c19acffb&redirect_uri=https%3A%2F%2Fwx.qq.com%2Fcgi-bin%2Fmmwebwx-bin%2Fwebwxnewloginpage&fun=new&lang=zh_CN&_=$now";

my $response = $self->{ua}->get($url);
$self->{ua}->default_headers;
if ( $response->is_success ) {
    print $response->decoded_content;    # or whatever
    $r = $response->decoded_content;
    print "\n";
}
else {
    die $response->status_line;
}

if ( $r =~ /window\.QRLogin\.code = 200; window\.QRLogin\.uuid = "(.*?)"/g ) {
    $uuid = $1;  
    $self->{uuid}=$uuid;
};
my $api      = "https://login.weixin.qq.com/qrcode/$uuid";
my $response = $self->{ua}->get($api);
$self->{ua}->default_headers;
if ( $response->is_success ) {
    $r = $response->decoded_content;    # or whatever
    print "\n";
}
else {
    die $response->status_line;
}

my ( $fh, $filename ) =
  tempfile( "weixin_qrcode_XXXX", SUFFIX => ".jpg", DIR => "/tmp" );
binmode $fh;
print $fh $r;
close $fh;
print "登录二维码已经下载到本地 [ $filename ] \n";

};
1;
