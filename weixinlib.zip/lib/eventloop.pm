package eventloop;

use AE;
use AnyEvent;
##定义watch
sub on_receive_msg {
my $self=shift;
my $code=shift;
print "__PACKAGE___  was called\n";
my $t = AnyEvent->timer(
        after    => 0,
        interval => $self->{interval},
        cb       => $code
    );
    ##不要再每秒打印时间
    ##undef $t;
    my $cv = AnyEvent->condvar;
    $cv->recv;
};
1;

