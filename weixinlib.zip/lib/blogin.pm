package blogin;

sub  blogin{
my $self=shift;
my $show_tip = 1;

my $uuid=$self->{uuid};

my $now =$self->{now};

###模拟登录:

while (1) {
        my $api = "https://login.weixin.qq.com/cgi-bin/mmwebwx-bin/login?loginicon=true&uuid=$uuid&tip=$show_tip&r=-$now&_=$now";
        print "\$api is $api\n";
        my $response = $self->{ua}->get($api);
        $self->{ua}->default_headers;
        if ( $response->is_success ) {
            $r = $response->decoded_content;
            print "\$r is $r\n";
            next unless defined $r;
            my %data = $r =~ /window\.(.+?)=(.+?);/g;

            if ( $data{code} == 201 ) {
                print
"手机微信扫码成功，请在手机微信上点击 [登录] 按钮...\n";
                my $show_tip = 0;
                next;
            }
            elsif ( $data{code} == 200 ) {
                print "正在进行登录...\n";
                foreach ($r) {
                    if ( $_ =~ /window.redirect_uri="(.*?)"/ ) {
                        $api = $1;
                        print "\$api is $api\n";
                        my $response = $self->{ua}->get($api);
                        $self->{ua}->default_headers;
                    }
                }


                foreach ($api) {
                    if ( $_ =~
/https\:\/\/wx\.qq\.com\/cgi\-bin\/mmwebwx-bin\/webwxnewloginpage\?ticket=(.*?)\&uuid=(.*?)\&lang=(.*?)\&scan=(.*)/
                      )
                    {
                        print "\$1 is $1\n";
                        print "\$2 is $2\n";
                        print "\$3 is $3\n";
                        print "\$4 is $4\n";
                        $ticket=$1;
                        $user = $4;
						$self->{user}=$user;
						$self->{ticket}=$ticket;
                        print "\$user is $user\n";
                        return 1;
                    }
                }

            }
            else {
                die $response->status_line;
            }

        }
    }



};
1;

