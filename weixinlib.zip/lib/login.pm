﻿package login;
use LWP::UserAgent;
use URI::Escape;
use Net::Ping;
use JSON qw(encode_json);
use Socket;
use Net::SMTP;
use LWP;
use LWP::Simple;
use LWP::UserAgent;
use HTTP::Cookies;
use HTTP::Headers;
use HTTP::Response;
use Encode;
use URI::Escape;
use URI::URL;
use File::Temp qw/tempfile/;
use AE;
 sub login {
 my $self=shift;
 my $ticket=$self->{'ticket'};
 my $uuid=$self->{'uuid'};
my $user=$self->{'user'};
  
my $api =
"https://wx.qq.com/cgi-bin/mmwebwx-bin/webwxnewloginpage?ticket=$ticket&uuid=$uuid&lang=zh_CN&scan=$user&fun=new&version=v2&lang=zh_CN";
    my $response = $self->{ua}->get($api);
    $self->{ua}->default_headers;

    if ( $response->is_success ) {
        print $response->decoded_content;    # or whatever
        $r = $response->decoded_content;
        if ( $r =~
/\<error.*\<skey\>(.*?)\<\/skey\>\<wxsid\>(.*?)\<\/wxsid\>\<wxuin\>(.*?)\<\/wxuin\>\<pass_ticket\>(.*?)\<\/pass_ticket.*/
          )
        {
            $Skey        = $1;
            $wxsid       = $2;
            $wxuin       = $3;
            $pass_ticket = $4;

            print "\$Skey is $Skey\n";
            print "\$wxsid is $wxsid\n";
            print "\$wxuin is $wxuin\n";
            print "\$pass_ticket is $pass_ticket\n";
            $Skey_x = uri_escape($Skey);
            use POSIX;
            my $a = "e";
            for ( my $b = 0 ; 15 > $b ; $b++ ) {
                $a .= POSIX::floor( 10 * rand() );
            }
            $DeviceID = $a;
            $self->{Skey}= $Skey;
            $self->{wxsid}=$wxsid;
            $self->{wxuin}=$wxuin;
            $self->{pass_ticket}=$pass_ticket;
            $self->{DeviceID}=$DeviceID;
            $self->{Uri_Skey}= uri_escape($Skey);
        }

    }
};
1;
