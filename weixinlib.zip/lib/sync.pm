package sync;
use LWP::UserAgent;
use URI::Escape;
use Net::Ping;
use JSON qw(encode_json);
use Socket;
use Net::SMTP;
use LWP;
use LWP::Simple;
use LWP::UserAgent;
use HTTP::Cookies;
use HTTP::Headers;
use HTTP::Response;
use Encode;
use URI::Escape;
use URI::URL;
sub sync{

my ($self,$msg,$FromUserName,$ToUserName)=@_;

print "sync-FromUserName is $FromUserName\n" ;
print "sync-ToUserName is $ToUserName\n" ;
my $now=$self->{now};
my $wxsid=$self->{wxsid};
my $wxuin=$self->{wxuin};
my $DeviceID=$self->{DeviceID};
my $synckey=$self->{synckey};
my $Skey=$self->{Skey};
my $pass_ticket=$self->{pass_ticket};

##注意微信根据$t生成报文ID,如果时间一样那么报文ID一致
my $t = time();

$url ="https://wx.qq.com/cgi-bin/mmwebwx-bin/webwxsendmsg?pass_ticket=$pass_ticket";
     my @query_string = (
            sid         => $wxsid,
            skey        => $Skey,
            r           => $now,
            pass_ticket => $pass_ticket
        );
   
    my $post = {
        BaseRequest =>  {
              Uin      => $wxuin,
            Sid      => $wxsid,
            Skey     => $Skey,
            DeviceID => $DeviceID,
        },
        Msg             => {
            ClientMsgId     =>  $t,
            Content         =>  decode("utf8",$msg),
            FromUserName    =>  $FromUserName,
            LocalID         =>  $t,
            ToUserName      =>  $ToUserName,
            Type            =>  1,
        },
    };

     use JSON qw(encode_json);
        $json_string = encode_json($post);

        my $req = HTTP::Request->new(
            'POST' => $url,
            [
                'pass_ticket' => "$pass_ticket"
            ]
        );
       # $req->referer("https://wx.qq.com/?&lang=zh_CN");
        $req->content_type('application/json; charset=UTF-8')
          ;    #post请求,如果有发送参数，必须要有这句
        $req->content("$json_string");    #发送post的参数
        my $res = $self->{ua}->request($req);
        print $res->as_string();
        print $res->content();#获取的是响应正文
        print "call sync--sync\n";
        print "\n";

};
1;