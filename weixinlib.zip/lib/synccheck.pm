﻿package synccheck;
use LWP::UserAgent;
use URI::Escape;
use Net::Ping;
use JSON qw(encode_json);
use Socket;
use Net::SMTP;
use LWP;
use LWP::Simple;
use LWP::UserAgent;
use HTTP::Cookies;
use HTTP::Headers;
use HTTP::Response;
use Encode;
use URI::Escape;
use URI::URL;
use File::Temp qw/tempfile/;
use AE;
unshift(@INC,"/root/scanwx/lib"); 
use send_text_msg;

sub synccheck {
my $self=shift;

my $now=time();
my $Uri_Skey=$self->{Uri_Skey};
my $wxsid=$self->{wxsid};
my $wxuin=$self->{wxuin};
my $DeviceID=$self->{DeviceID};
my $synckey=$self->{synckey};
my $Skey=$self->{Skey};
my $pass_ticket=$self->{pass_ticket};

 my $url ="https://webpush.weixin.qq.com/cgi-bin/mmwebwx-bin/synccheck?r=$now&skey=$Uri_Skey&sid=$wxsid&uin=$wxuin&deviceid=$DeviceID&synckey=$synckey&_=$now";

    my $response = $self->{ua}->get($url);
    $self->{ua}->default_headers;

    if ( $response->is_success ) {
        $r = $response->decoded_content;
    }

##window.synccheck={retcode:"0",selector:"0"}
    if ( $r =~ /window.*selector:"(.*?)"}/ ) {
	    
        $selector = $1;
		print "\$selector is $selector\n";
     #$self->{selector}=$selector;
	
	  
    };
	
	 if (($selector) and ( $selector != 0 )) {

my  $sync_url ="https://wx.qq.com/cgi-bin/mmwebwx-bin/webwxsync?sid=$wxsid&skey=$Skey&lang=zh_CN&pass_ticket=$pass_ticket";
print "\$sync_url is $sync_url\n";
my @query_string=();

        my @query_string = (
            sid         => $wxsid,
            skey        => $Skey,
            r           => $now,
            pass_ticket => $pass_ticket
        );
        my $post = {
            BaseRequest => { Uin => $wxuin, Sid => $wxsid },
            SyncKey     => $self->{m},
            rr          => $now
        };
        use JSON qw(encode_json);
        $json_string = encode_json($post);

        my $req = HTTP::Request->new(
            'POST' => $sync_url,
            [
                'lang'        => 'zh_CN',
                'pass_ticket' => "$pass_ticket",
                'sid'         => $wxsid,
                'skey'        => $Skey
            ]
        );
        $req->referer("https://wx.qq.com/?&lang=zh_CN");
        $req->content_type('application/json; charset=UTF-8')
          ;    #post请求,如果有发送参数，必须要有这句
        $req->content("$json_string");    #发送post的参数
        my $res = $self->{ua}->request($req);
        print "-------------syncinfo-----------------\n";

         print $res->status_line."\n";
         #print $res->as_string();#获取的是原始内容，包括响应头，响应正文
        # print $res->content();#获取的是响应正文
        $d = $res->content();
        use JSON qw/encode_json decode_json/;
		eval{if ($d){
        $d       = encode_utf8($d);
        $d       = decode_json($d);
		
        $m       = $d->{SyncKey};
        $synckey = "";
        $count = $m->{Count};
		$UserName= $d->{User}->{UserName};
		print $d->{User}->{UserName};
		print "\n";
		};
};
        print "\$count is $count\n";
        for ( $i = 0 ; $i <= $count - 1 ; $i++ ) {

            #print $m->{List}->[$i]->{Val};
            #print $m->{List}->[$i]->{Key};
            $synckey .= "$m->{List}->[$i]->{Key}\_$m->{List}->[$i]->{Val}\|";

        };
###$j每个元素,元素内容为引用
foreach $j (@{$d->{AddMsgList}}) {
use Data::Dumper;
 my $var= Dumper($j);
	  # my $var=encode("gbk",decode("utf8","$var"));
  if ("$j->{MsgType}" == 1){
  print "\$message is $j->{Content}\n";
  print "\n";


## 群消息@d91e48886e46846a143e4dc4f0430ae464469faf3d20c1fc108f34936906789f:<br/>那jiandan
#@734f2197ad7f69b5d6bdc4e7051eead7a95b191d9204861f7232bb496ef456f2:<br/>jj
$recm=  $j->{Content};

if ($recm =~/^(\@.+):<br\/>(.*)/g){
$recm=$2;
print "\$recm is $recm\n";
};

$synckey =~ s/\|$//;
$synckey = uri_escape($synckey);

print "\$synckey  is $synckey \n";

$FromUserName=$j->{FromUserName};
$ToUserName=$j->{ToUserName};
$self->{synckey}=$synckey;
$self->{Uri_Skey}=$Uri_Skey;
$self->{m}=$m ;
$self->{FromUserName}=$FromUserName;
$self->{UserName}=$ToUserName;
$self->{recm}=$recm;
#$Username  表示机器人自己,发送的人不是机器人自己
print "\$FromUserName is $FromUserName\n";

print "\$UserName is $UserName\n";

print "\$ToUserName is $ToUserName\n";
if ($FromUserName ne $ToUserName){ 
print "come in send_text_msg\n";
send_text_msg::send_text_msg($self);
 }

}else {print "now not support message  $j->{MsgType}\n";}
};


}

};
	
	1;








